======================
 Weekly exercise #022
======================

Polymorphic variants in OCaml exist to permit a more flexible use of variants. This exercise illustrates the expressive power of polymorphic variants with respect to traditional variants.

The code provided with this exercise provides a complete implementation of an interactive repl for a basic lambda calculus interpreter. Here's a tiny example session:
```

  d:\lab_022>.\lambda.exe
  ? (\p x y.p x y) (\x y. x) a b
  a
  ? (\p x y.p x y) (\x y. y) a b
  b

(`\x y. x` is a \lambda encoding of the boolean value `true`, `\x y. y` an encoding of the boolean value `false` and `\p x y. p x y` an encoding of "if-then-else".)

The module `Var` defines a basic language containing only variables. 
```
  type 'a impl = [`Var of string]

Evaluation for this language is achieved by looking in an environment for a binding associated to the variable name leaving it "as is" if there is none. 

The module `Lambda` extends this basic language to define the \lambda calculus.
```
  type 'a impl = ['a Var.impl | `Abs of string * 'a | `App of 'a * 'a]

The type `'a impl` is carefully defined to be open recursive (subterms of of type`a) and open recursion is used in `eval_impl` so as to be able to extend this definition later. Finally in module `Lambda`, the function `eval` builds a specific evaluator for the language by closing the recursion. This function closes the recursion at both the runtime and type levels : both input and output types are `type t = 'a impl as 'a`.

In a similar fashion as in the `Lambda` module, the module `Arith` builds on the base language of variables to define the language of additive and multiplicative expressions.

The exercise is to write the code that combines the language of arithmetic expressions with the lambda calculus. This code goes in module `Lambda_with_arithmetic`. A parser for this language is provided in the files `lambda_with_arithmetic.lexer` and `lambda_with_arithmetic.mly` and a repl. Here's an example session with the completed product:
```
  d:\lab022>.\lambda_with_arithmetic.exe
  .\lambda_with_arithmetic.exe
  ? (\p x y.p x y) (\x y. x) a b
  a
  ? (\x y. x * y) ((\x y. x + y) 2 3) 5
  25

A build script is provided. You'll need to uncomment a region in it when it comes time to build your "lambda-calculus with arithmetic" interpreter.
