type token =
  | Tident of (string)
  | Tnum of (int)
  | Tlambda
  | Tdot
  | Tlparen
  | Trparen
  | Teof

open Parsing;;
let _ = parse_error;;
# 2 "lambda_parser.mly"
type t = Lambda.t

let var (s : string) : t = 
  Var.mk_var s

let abs ((bs : string list), (t : t)) : t =
  List.fold_right (fun b u -> Lambda.mk_abs (b, u)) bs t
let app ((t0 : t), (us : t list)) : t =
  List.fold_left (fun t u -> Lambda.mk_app (t, u)) t0 us

# 24 "lambda_parser.ml"
let yytransl_const = [|
  259 (* Tlambda *);
  260 (* Tdot *);
  261 (* Tlparen *);
  262 (* Trparen *);
  263 (* Teof *);
    0|]

let yytransl_block = [|
  257 (* Tident *);
  258 (* Tnum *);
    0|]

let yylhs = "\255\255\
\001\000\002\000\002\000\006\000\006\000\005\000\005\000\004\000\
\004\000\003\000\000\000"

let yylen = "\002\000\
\002\000\005\000\002\000\000\000\002\000\001\000\003\000\000\000\
\002\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\010\000\000\000\000\000\011\000\000\000\006\000\
\000\000\000\000\000\000\001\000\000\000\003\000\000\000\000\000\
\007\000\005\000\009\000\000\000\002\000"

let yydgoto = "\002\000\
\006\000\007\000\008\000\016\000\009\000\014\000"

let yysindex = "\002\000\
\001\255\000\000\000\000\007\255\001\255\000\000\006\255\000\000\
\004\255\007\255\005\255\000\000\004\255\000\000\007\255\014\255\
\000\000\000\000\000\000\001\255\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\010\255\015\255\000\000\000\000\010\255\000\000\015\255\000\000\
\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\251\255\253\255\005\000\001\000\008\000"

let yytablesize = 21
let yytable = "\011\000\
\010\000\003\000\001\000\004\000\003\000\005\000\015\000\003\000\
\005\000\013\000\017\000\015\000\012\000\013\000\021\000\004\000\
\004\000\020\000\008\000\019\000\018\000"

let yycheck = "\005\000\
\004\000\001\001\001\000\003\001\001\001\005\001\010\000\001\001\
\005\001\009\000\006\001\015\000\007\001\013\000\020\000\006\001\
\007\001\004\001\004\001\015\000\013\000"

let yynames_const = "\
  Tlambda\000\
  Tdot\000\
  Tlparen\000\
  Trparen\000\
  Teof\000\
  "

let yynames_block = "\
  Tident\000\
  Tnum\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'term) in
    Obj.repr(
# 25 "lambda_parser.mly"
              ( _1 )
# 98 "lambda_parser.ml"
               : Lambda.t))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : 'id) in
    let _3 = (Parsing.peek_val __caml_parser_env 2 : 'id_list) in
    let _5 = (Parsing.peek_val __caml_parser_env 0 : 'term) in
    Obj.repr(
# 28 "lambda_parser.mly"
                                 ( abs ((_2 :: _3), _5) )
# 107 "lambda_parser.ml"
               : 'term))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'atom) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'atom_list) in
    Obj.repr(
# 29 "lambda_parser.mly"
                   ( app (_1, _2) )
# 115 "lambda_parser.ml"
               : 'term))
; (fun __caml_parser_env ->
    Obj.repr(
# 32 "lambda_parser.mly"
    ( [] )
# 121 "lambda_parser.ml"
               : 'atom_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'atom) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'atom_list) in
    Obj.repr(
# 33 "lambda_parser.mly"
                   ( _1 :: _2 )
# 129 "lambda_parser.ml"
               : 'atom_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'id) in
    Obj.repr(
# 36 "lambda_parser.mly"
       ( var _1 )
# 136 "lambda_parser.ml"
               : 'atom))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'term) in
    Obj.repr(
# 37 "lambda_parser.mly"
                         ( _2 )
# 143 "lambda_parser.ml"
               : 'atom))
; (fun __caml_parser_env ->
    Obj.repr(
# 40 "lambda_parser.mly"
    ( [] )
# 149 "lambda_parser.ml"
               : 'id_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'id) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'id_list) in
    Obj.repr(
# 41 "lambda_parser.mly"
               ( _1 :: _2 )
# 157 "lambda_parser.ml"
               : 'id_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 44 "lambda_parser.mly"
           ( _1 )
# 164 "lambda_parser.ml"
               : 'id))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Lambda.t)
;;
# 47 "lambda_parser.mly"

# 191 "lambda_parser.ml"
