(*Your code goes here*)

type t

let rec string_of_t : t -> string = 
  failwith "Not implemented"

let rec eval (env : (string * t) list) : 'a -> 'a  =
  failwith "Not implemented"
